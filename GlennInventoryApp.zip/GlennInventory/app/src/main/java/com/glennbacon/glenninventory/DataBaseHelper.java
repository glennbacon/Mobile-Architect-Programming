package com.glennbacon.glenninventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {

    public static final String LOGIN_TABLE = "LOGIN_TABLE";
    public static final String COLUMN_USERNAME = "USERNAME";
    public static final String COLUMN_PASSWORD = "PASSWORD";
    public static final String COLUMN_ID = "ID";

    public static final String INVENTORY_TABLE = "INVENTORY_TABLE";
    public static final String COLUMN_ITEM = "ITEM";
    public static final String COLUMN_QTY = "QTY";

    public DataBaseHelper(@Nullable Context context) {
        super(context, "database.db", null, 1);
    }

    // Called first time database is accessed and is used to create new database
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create login table
        String createTableStatement = "CREATE TABLE " + LOGIN_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USERNAME + " TEXT, " + COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createTableStatement);

        // Create inventory item table
        createTableStatement = "CREATE TABLE " + INVENTORY_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_ITEM + " TEXT, " + COLUMN_QTY + " INTEGER)";
        db.execSQL(createTableStatement);
    }

    // Called when database version number changes to update old database to new database table(s)
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addUser(LoginModel loginModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_USERNAME, loginModel.getUsername());
        cv.put(COLUMN_PASSWORD, loginModel.getPassword());

        long insert = db.insert(LOGIN_TABLE, null, cv);

        if (insert == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    public boolean addItem(InventoryModel inventoryModel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ITEM, inventoryModel.getItem());
        cv.put(COLUMN_QTY, inventoryModel.getQty());

        long insert = db.insert(INVENTORY_TABLE, null, cv);

        if (insert == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    public boolean deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        db.execSQL("DELETE FROM " + INVENTORY_TABLE + " WHERE " + COLUMN_ID + " = " + Integer.toString(id) +";");

        return true;
    }

    public List<LoginModel> getEveryone() {
        List<LoginModel> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " + LOGIN_TABLE;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()) {
            do {
                int loginID = cursor.getInt(0);
                String loginUsername = cursor.getString(1);
                String loginPassword = cursor.getString(2);

                LoginModel newLogin = new LoginModel(loginID, loginUsername, loginPassword);
                returnList.add(newLogin);

            } while(cursor.moveToNext());
        }
        else {
            // failed to add to list
        }

        // close database and cursor
        cursor.close();
        db.close();

        return returnList;
    }

    public List<InventoryModel> getEveryItem() {
        List<InventoryModel> returnList = new ArrayList<>();

        String queryString = "SELECT * FROM " + INVENTORY_TABLE;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()) {
            do {
                int itemID = cursor.getInt(0);
                String itemName = cursor.getString(1);
                int itemQty = cursor.getInt(2);

                InventoryModel newItem = new InventoryModel(itemID, itemName, itemQty);
                returnList.add(newItem);

            } while(cursor.moveToNext());
        }
        else {
            // failed to add to list
        }

        // close database and cursor
        cursor.close();
        db.close();

        return returnList;
    }
}
