package com.glennbacon.glenninventory;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import java.util.List;
import java.util.ListIterator;

public class ThirdFragment extends Fragment {
    InventoryModel inventoryModel;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_third, container, false);
    }

    @SuppressLint("SetTextI18n")
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Get and load items from database and populate listview
        ListView listView = requireActivity().findViewById(R.id.lv_inventoryList);
        DataBaseHelper dataBaseHelper = new DataBaseHelper(getContext());
        List<InventoryModel> itemList = dataBaseHelper.getEveryItem();
        ArrayAdapter itemArrayAdapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_list_item_1, itemList);
        listView.setAdapter(itemArrayAdapter);

        /* Save Item Name and Qty to database, if item exists update item with new qty.
            If the Item Name field is empty display a toast message.
         */
        view.findViewById(R.id.button_Save).setOnClickListener(v -> {
            // EditText for Item Name
            EditText editTextItem = requireActivity().findViewById(R.id.editTextItem);
            String itemName = editTextItem.getText().toString();

            // EditText for Qty
            EditText editTextQty= requireActivity().findViewById(R.id.editTextQty);
            int itemQty = Integer.parseInt(editTextQty.getText().toString());

            boolean success;
            boolean itemExists = false;
            int itemId = 0;
            InventoryModel dbInventoryModel;

            if(itemName.isEmpty()){
                Toast.makeText(getContext(), "Item name is empty.", Toast.LENGTH_SHORT).show();
            }
            else {
                try {
                    inventoryModel = new InventoryModel(-1, itemName, itemQty);
                } catch (Exception e) {
                    Toast.makeText(getContext(), "Error saving item: " + e.toString(), Toast.LENGTH_SHORT).show();
                }

                List<InventoryModel> userList = dataBaseHelper.getEveryItem();

                for (InventoryModel model : userList) {
                    dbInventoryModel = model;
                    if (dbInventoryModel.getItem().equals(inventoryModel.getItem())) {
                        itemId = dbInventoryModel.getId();
                        itemExists = true;
                    }
                }

                // Edit item by deleting and saving
                if (itemExists) {
                    dataBaseHelper.deleteItem(itemId);
                }
                inventoryModel = new InventoryModel(-1, itemName, itemQty);
                success = dataBaseHelper.addItem(inventoryModel);
                if(success) {
                    Toast.makeText(getContext(), "Item saved.", Toast.LENGTH_SHORT).show();
                }
            }

            @SuppressWarnings("rawtypes") ArrayAdapter itemArrayAdapter1 = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, dataBaseHelper.getEveryItem());
            listView.setAdapter(itemArrayAdapter1);
        });

        // Delete item from database and update listview
        view.findViewById(R.id.button_Delete).setOnClickListener(v -> {
            EditText editTextItem = requireActivity().findViewById(R.id.editTextItem);
            String itemName = editTextItem.getText().toString();

            try {
                inventoryModel = new InventoryModel(-1, itemName, 0);
            } catch (Exception e) {
                Toast.makeText(getContext(), "Error deleting item: " + e.toString(), Toast.LENGTH_SHORT).show();
            }

            ListIterator<InventoryModel> listIterator = dataBaseHelper.getEveryItem().listIterator();
            InventoryModel tempItem;
            while (listIterator.hasNext()) {
                tempItem = listIterator.next();

                if (tempItem.getItem().equals(inventoryModel.getItem())) {
                    dataBaseHelper.deleteItem(tempItem.getId());
                }
            }

            ArrayAdapter itemArrayAdapter12 = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, dataBaseHelper.getEveryItem());
            listView.setAdapter(itemArrayAdapter12);
        });

        // Increase item qty by 1
        view.findViewById(R.id.button_Plus).setOnClickListener(v -> {
            EditText editTextQty= requireActivity().findViewById(R.id.editTextQty);
            int itemQty = Integer.parseInt(editTextQty.getText().toString());
            itemQty++;
            editTextQty.setText(Integer.toString(itemQty));
        });

        // Reduce item qty by 1
        view.findViewById(R.id.button_Minus).setOnClickListener(v -> {
            EditText editTextQty= requireActivity().findViewById(R.id.editTextQty);
            int itemQty = Integer.parseInt(editTextQty.getText().toString());
            if(itemQty >= 1) {
                itemQty--;
            }
            editTextQty.setText(Integer.toString(itemQty));
        });

        // Click on listview item and update Item Name EditText and Qty
        listView.setOnItemClickListener((parent, view1, position, id) -> {
            List<InventoryModel> intentoryItemList = dataBaseHelper.getEveryItem();
            @SuppressWarnings("rawtypes") ArrayAdapter itemArrayAdapter13 = new ArrayAdapter<>(getContext(),
                    android.R.layout.simple_list_item_1, intentoryItemList);
            listView.setAdapter(itemArrayAdapter13);

            EditText editTextItem = requireActivity().findViewById(R.id.editTextItem);
            editTextItem.setText(intentoryItemList.get((int)id).getItem());
            EditText editTextQty= requireActivity().findViewById(R.id.editTextQty);
            editTextQty.setText(Integer.toString(intentoryItemList.get((int)id).getQty()));
        });
    }
}
