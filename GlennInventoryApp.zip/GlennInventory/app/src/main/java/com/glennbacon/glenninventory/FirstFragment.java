package com.glennbacon.glenninventory;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import java.util.List;

public class FirstFragment extends Fragment {
    LoginModel loginModel;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_first, container, false);
    }

    // Listener watches for changes to EditText field
    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        @Override
        public void afterTextChanged(Editable s) {
            Button buttonLogin = requireActivity().findViewById(R.id.button_login);
            Button buttonRegister = requireActivity().findViewById(R.id.button_register);
            EditText editTextUsername = requireActivity().findViewById(R.id.username);
            EditText editTextPassword = requireActivity().findViewById(R.id.password);

            if (s == editTextUsername.getEditableText() || s == editTextPassword.getEditableText()) {
                // nameText doesn't have text update button and textGreeting
                if (!editTextUsername.getText().toString().isEmpty() && !editTextPassword.getText()
                        .toString().isEmpty()) {
                    buttonLogin.setEnabled(true);
                    buttonRegister.setEnabled(true);
                }
                if (editTextUsername.getText().toString().isEmpty()) {
                    buttonLogin.setEnabled(false);
                    buttonRegister.setEnabled(false);
                }
                if (editTextPassword.getText().toString().isEmpty()) {
                    buttonLogin.setEnabled(false);
                    buttonRegister.setEnabled(false);
                }
            }
        }
    };

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        view.findViewById(R.id.button_login).setOnClickListener(view1 -> {
            EditText editTextPassword = requireActivity().findViewById(R.id.password);
            String password = editTextPassword.getText().toString();
            EditText editTextUsername = requireActivity().findViewById(R.id.username);
            String username = editTextUsername.getText().toString();
            boolean userExists = false;
            LoginModel dbLoginModel;

            try {
                loginModel = new LoginModel(-1, username, password);
            } catch (Exception e) {
                Toast.makeText(getContext(), "Error registering user: " + e.toString(), Toast.LENGTH_SHORT).show();
            }
            DataBaseHelper dataBaseHelper = new DataBaseHelper(getContext());

            List<LoginModel> userList = dataBaseHelper.getEveryone();

            for (LoginModel model : userList) {
                dbLoginModel = model;
                if (dbLoginModel.getUsername().equals(loginModel.getUsername()) && dbLoginModel.getPassword().equals(loginModel.getPassword())) {
                    userExists = true;
                }
            }

            if (userExists) {
                Toast.makeText(getActivity(), "Login success.", Toast.LENGTH_SHORT).show();
                NavHostFragment.findNavController(FirstFragment.this).navigate(R.id.action_FirstFragment_to_SecondFragment);
            } else {
                Toast.makeText(getContext(), "Username and or password incorrect.", Toast.LENGTH_SHORT).show();
            }

        });

        view.findViewById(R.id.button_register).setOnClickListener(view12 -> {
            EditText editTextPassword = requireActivity().findViewById(R.id.password);
            String password = editTextPassword.getText().toString();
            EditText editTextUsername = requireActivity().findViewById(R.id.username);
            String username = editTextUsername.getText().toString();
            boolean userExists = false;

            try {
                loginModel = new LoginModel(-1, username, password);
            } catch (Exception e) {
                Toast.makeText(getContext(), "Error registering user: " + e.toString(), Toast.LENGTH_SHORT).show();
            }
            DataBaseHelper dataBaseHelper = new DataBaseHelper(getContext());

            List<LoginModel> userList = dataBaseHelper.getEveryone();

            for (LoginModel model : userList) {
                if (model.getUsername().equals(loginModel.getUsername())) {
                    userExists = true;
                    break;
                }
            }

            if (!userExists) {
                boolean success = dataBaseHelper.addUser(loginModel);
                if(success){
                    Toast.makeText(getActivity(), "Success, user account created.", Toast.LENGTH_SHORT).show();
                    NavHostFragment.findNavController(FirstFragment.this).navigate(R.id.action_FirstFragment_to_SecondFragment);
                }
            } else {
                Toast.makeText(getContext(), "Sorry, username is already taken.", Toast.LENGTH_SHORT).show();
            }

        });

        // Create a text listener
        EditText editTextUsername = requireActivity().findViewById(R.id.username);
        EditText editTextPassword = requireActivity().findViewById(R.id.password);
        editTextUsername.addTextChangedListener(textWatcher);
        editTextPassword.addTextChangedListener(textWatcher);
    }
}
