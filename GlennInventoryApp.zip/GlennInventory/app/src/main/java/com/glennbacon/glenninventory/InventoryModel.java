package com.glennbacon.glenninventory;

public class InventoryModel {
    private int id;
    private String item;
    private int qty;

    // Constructors
    public InventoryModel(int id, String item, int qty) {
        this.id = id;
        this.item = item;
        this.qty = qty;
    }

    public InventoryModel() {
    }

    @Override
    public String toString() {
        return "InventoryModel{" +
                "id=" + id +
                ", item='" + item + '\'' +
                ", qty='" + Integer.toString(qty) + '\'' +
                '}';
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String username) {
        this.item = item;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(String password) {
        this.qty = qty;
    }
}
